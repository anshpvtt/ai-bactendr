# AI Doubt Solver Backend

This is the backend for AI Doubt Solver. 
It uses Google Vision API (OCR) + Gemini API to solve questions.

## 🚀 How to Deploy on Render

1. Push this code to a new GitHub repository.
2. Go to [Render.com](https://render.com/) → New Web Service → connect your repo.
3. In **Environment Variables**, add:
   ```
   GOOGLE_API_KEY=your_google_api_key_here
   ```
4. Deploy 🚀
5. After deploy, you’ll get a backend URL like:
   ```
   https://your-app.onrender.com
   ```

Frontend should use:
```
https://your-app.onrender.com/api/solve
```
